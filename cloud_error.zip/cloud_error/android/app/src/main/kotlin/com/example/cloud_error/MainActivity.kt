package com.example.cloud_error

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
